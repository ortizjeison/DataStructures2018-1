
public class Cajero extends Empleado{

	public Cajero(Banco b, int id, String nombre, int telefono, String oficina, String email) {
		super(b, id, nombre, telefono, oficina, email);
		// TODO Auto-generated constructor stub
	}
	
	
	public void SolicitudPrestamo() {
		
	}
	
	

	
}
