
public class Consignacion {

}
